let userLatitude = 35.681236; // 기본 위치: 도쿄역 (위도)
let userLongitude = 139.767125; // 기본 위치: 도쿄역 (경도)
let currentPage = 1; // 현재 페이지 번호
const resultsPerPage = 10; // 한 번에 표시할 결과 수
const pagesToShow = 10; // 한 번에 표시할 페이지 번호 수
let map; // Google Maps 객체
let markers = []; // 지도에 추가된 마커를 저장하는 배열
let detailMap; // 상세 페이지에 추가된 지도 객체
let currentLocationMarker; // 현재 위치를 나타내는 마커

// 지도를 초기화하는 함수
function initMap() {
    const mapOptions = {
        center: { lat: userLatitude, lng: userLongitude },
        zoom: 17 // 줌 레벨을 17로 고정
    };
    map = new google.maps.Map(document.getElementById('map'), mapOptions);

    // "현재 위치" 마커를 지도에 추가
    currentLocationMarker = new google.maps.Marker({
        position: { lat: userLatitude, lng: userLongitude },
        map: map,
        title: '현재 위치', // 마커 제목을 "현재 위치"로 설정
        icon: {
            path: google.maps.SymbolPath.CIRCLE,
            scale: 8,
            fillColor: '#4285F4',
            fillOpacity: 1,
            strokeColor: '#ffffff',
            strokeWeight: 2
        }
    });
}

// 사용자의 현재 위치를 가져오는 함수
function getLocation() {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
            position => {
                // 성공적으로 위치를 가져온 경우
                userLatitude = position.coords.latitude;
                userLongitude = position.coords.longitude;
                initMap(); // 지도 초기화
                searchRestaurants(); // 위치를 가져온 후 자동으로 검색 시작
            },
            error => {
                // 위치 정보를 가져오지 못한 경우
                alert("위치 정보를 가져오지 못했습니다. 도쿄역을 기본값으로 사용합니다.");
                console.error(error);
                initMap(); // 기본 위치로 지도 초기화
                searchRestaurants(); // 기본 위치(도쿄역)로 검색 시작
            }
        );
    } else {
        alert("이 브라우저에서는 위치 정보 기능을 지원하지 않습니다. 도쿄역을 기본값으로 사용합니다.");
        initMap(); // 기본 위치로 지도 초기화
        searchRestaurants(); // 기본 위치(도쿄역)로 검색 시작
    }
}

// Hot Pepper API를 사용해 식당 검색을 수행하는 함수
function searchRestaurants() {
    currentPage = 1; // 검색 시 페이지를 초기화
    performSearch();
}

// 실제 검색을 수행하는 함수
function performSearch() {
    const proxyUrl = 'https://cors-anywhere.herokuapp.com/'; // CORS 프록시 서버 URL
    const apiKey = 'f781b758746f24b7'; // 실제 Hot Pepper API 키
    const sortOption = document.getElementById('sort').value; // 정렬 옵션
    const selectedRadius = document.getElementById('radius').value; // Hot Pepper API의 range 옵션 (1, 2, 3, 4, 5)
    const apiUrl = `https://webservice.recruit.co.jp/hotpepper/gourmet/v1/?key=${apiKey}&lat=${userLatitude}&lng=${userLongitude}&range=${selectedRadius}&order=${sortOption}&start=${(currentPage - 1) * resultsPerPage + 1}&count=${resultsPerPage}&format=json`;

    // Hot Pepper API 호출
    fetch(proxyUrl + apiUrl)
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            if (data.results.shop && data.results.shop.length > 0) {
                calculateWalkingTimes(data.results.shop); // Google Maps API로 도보 시간 계산
                updatePagination(data.results.results_available); // 전체 결과 수로 페이징 업데이트
                addMarkersToMap(data.results.shop); // 지도에 마커 추가
            } else {
                console.log("검색 결과가 없습니다.");
                displayResults([]);
                updatePagination(0); // 검색 결과가 없는 경우 페이징을 업데이트하지 않음
            }
        })
        .catch(error => console.error('Hot Pepper API Error:', error));
}

// Google Maps Distance Matrix API를 사용해 도보 시간을 계산하는 함수
function calculateWalkingTimes(shops) {
    const origin = new google.maps.LatLng(userLatitude, userLongitude);
    const destinations = shops.map(shop => shop.address);

    const service = new google.maps.DistanceMatrixService();
    service.getDistanceMatrix(
        {
            origins: [origin],
            destinations: destinations,
            travelMode: 'WALKING', // 도보로 계산
        },
        (response, status) => {
            if (status === 'OK') {
                const filteredShops = [];
                response.rows[0].elements.forEach((element, index) => {
                    if (element.status === 'OK') {
                        const durationInMinutes = Math.round(element.duration.value / 60); // 도보 시간 (분)
                        shops[index].walkingTime = `${durationInMinutes} 분 소요`;
                        filteredShops.push(shops[index]);
                    }
                });
                displayResults(filteredShops); // 필터링된 결과 표시
            } else {
                console.error('Google Maps Distance Matrix API Error:', status);
            }
        }
    );
}

// 검색 결과를 지도에 마커로 표시하는 함수
// 검색 결과를 지도에 마커로 표시하는 함수
function addMarkersToMap(shops) {
    // 이전 마커 제거
    markers.forEach(marker => marker.setMap(null));
    markers = [];

    shops.forEach(shop => {
        const marker = new google.maps.Marker({
            position: { lat: parseFloat(shop.lat), lng: parseFloat(shop.lng) },
            map: map,
            title: shop.name // 마커 제목을 "가게 이름"으로 설정
        });

        // 마커 클릭 시 모달창 열기
        marker.addListener('click', () => {
            showShopDetails(shop);
        });

        // InfoWindow 생성
        const infoWindow = new google.maps.InfoWindow({
            content: `<div style="white-space: nowrap;">${shop.name}</div>` // 가게 이름을 포함한 HTML 설정
        });

        // 마커에 마우스를 올렸을 때 가게 이름을 툴팁으로 표시
        marker.addListener('mouseover', () => {
            infoWindow.open(map, marker);
        });

        // 마커에서 마우스를 뗐을 때 툴팁 닫기
        marker.addListener('mouseout', () => {
            infoWindow.close();
        });

        markers.push(marker);
    });
}



// 검색 결과를 화면에 표시하는 함수
function displayResults(shops) {
    const resultsDiv = document.getElementById('results');
    resultsDiv.innerHTML = '';

    if (shops && shops.length > 0) {
        shops.forEach((shop, index) => {
            let div = document.getElementById(`shop-${index}`);
            if (!div) {
                div = document.createElement('div');
                div.id = `shop-${index}`;
                div.classList.add('shop-item');
                resultsDiv.appendChild(div);
            }
            const walkingTimeText = shop.walkingTime ? `도보 소요 시간: ${shop.walkingTime}` : '소요 시간 정보를 가져오는 중...';
            div.innerHTML = `
                <img src="${shop.photo.pc.l}" alt="${shop.name}" width="100" height="100" />
                <div>
                    <h3>${shop.name}</h3>
                    <p>${walkingTimeText}</p>
                    <p>접근 방법: ${shop.access}</p>
                </div>
            `;
            div.onclick = () => showShopDetails(shop);
        });
    } else {
        resultsDiv.innerHTML = '검색 결과가 없습니다.';
    }
}

// 모달 창에 매장 상세 정보를 표시하는 함수
// 모달 창에 매장 상세 정보를 표시하는 함수
function showShopDetails(shop) {
    const detailsDiv = document.getElementById('details');
    detailsDiv.innerHTML = `
        <div style="display: flex; justify-content: space-between; align-items: center;">
            <h2 style="margin: 0;">${shop.name}</h2>
            <button class="close" onclick="closeModal()" aria-label="Close" style="margin-left: 10px;">&times;</button>
        </div>
        <img src="${shop.photo.pc.l}" alt="${shop.name} 이미지" width="300" height="200" style="margin: 5px;">
        <p><strong>주소:</strong> ${shop.address}</p>
        <p><strong>가게 장르:</strong> ${shop.genre.name}</p>
        <p><strong>영업 시간:</strong> ${shop.open}</p>
        <p><strong>평균 가격:</strong> ${shop.budget.average}</p>
        <p><strong>주차장:</strong> ${shop.parking}</p>
        <p><strong>카드 사용 여부:</strong> ${shop.card}</p>
        <p><strong>와이파이:</strong> ${shop.wifi}</p>
        <!-- 상세 페이지에 Google 지도와 길찾기 버튼 추가 -->
        <div id="detail-map" style="height: 300px; width: 100%; margin-top: 20px;"></div>
        <button onclick="openDirections('${shop.lat}', '${shop.lng}')" class="button">길찾기</button>
    `;
    openModal(); // 모달 창 열기

    // 상세 페이지에 지도 초기화
    detailMap = new google.maps.Map(document.getElementById('detail-map'), {
        center: { lat: parseFloat(shop.lat), lng: parseFloat(shop.lng) },
        zoom: 17 // 상세 페이지 지도 줌 레벨을 17로 고정
    });

    new google.maps.Marker({
        position: { lat: parseFloat(shop.lat), lng: parseFloat(shop.lng) },
        map: detailMap,
        title: shop.name
    });
}


// 길찾기 버튼 클릭 시 Google Maps 길찾기 페이지로 이동
function openDirections(lat, lng) {
    const directionsUrl = `https://www.google.com/maps/dir/?api=1&destination=${lat},${lng}&travelmode=walking`;
    window.open(directionsUrl, '_blank');
}

// 모달 창 열기
function openModal() {
    const modal = document.getElementById('modal');
    modal.style.display = 'flex'; // Flex로 설정하여 중앙에 표시
}

// 모달 창 닫기
function closeModal() {
    const modal = document.getElementById('modal');
    modal.style.display = 'none'; // 모달 창 숨기기
}

// 페이지네이션 버튼을 업데이트하는 함수
function updatePagination(totalResults) {
    const paginationDiv = document.getElementById('pagination');
    paginationDiv.innerHTML = ''; // 기존 버튼을 지우기

    const totalPages = Math.ceil(totalResults / resultsPerPage); 
    const startPage = Math.floor((currentPage - 1) / pagesToShow) * pagesToShow + 1;
    const endPage = Math.min(totalPages, startPage + pagesToShow - 1);

    if (startPage > 1) {
        const firstButton = document.createElement('button');
        firstButton.innerText = '<<';
        firstButton.onclick = () => changePage(1);
        paginationDiv.appendChild(firstButton);
    }

    if (currentPage > 1) {
        const prevButton = document.createElement('button');
        prevButton.innerText = '<';
        prevButton.onclick = () => changePage(currentPage - 1);
        paginationDiv.appendChild(prevButton);
    }

    for (let pageNum = startPage; pageNum <= endPage; pageNum++) {
        const pageButton = document.createElement('button');
        pageButton.innerText = pageNum;
        if (pageNum === currentPage) {
            pageButton.classList.add('active'); 
        } else {
            pageButton.onclick = () => changePage(pageNum);
        }
        paginationDiv.appendChild(pageButton);
    }

    if (currentPage < totalPages) {
        const nextButton = document.createElement('button');
        nextButton.innerText = '>';
        nextButton.onclick = () => changePage(currentPage + 1);
        paginationDiv.appendChild(nextButton);
    }

    if (endPage < totalPages) {
        const lastButton = document.createElement('button');
        lastButton.innerText = '>>';
        lastButton.onclick = () => changePage(totalPages);
        paginationDiv.appendChild(lastButton);
    }
}

// 페이지 변경 함수
function changePage(page) {
    currentPage = page;
    performSearch();
}
